function setup() {
  createCanvas(500, 500);
}

function draw() {
  fill(255, 0, 0);
  rect(50, 50, 200, 75);
}